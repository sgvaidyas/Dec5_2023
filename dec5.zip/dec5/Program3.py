def fun(a):
    a = a +100  #110
    return a

fun1 = lambda a : a + 50
fun2 = lambda a,b: a+b
fun3 = lambda  a : a*a

val = fun(10)
print(val)
val1 = fun1(10)
print(val1)
val2 = fun2(11,22)
print(val2)
val3 = fun3(5)
print(val3)