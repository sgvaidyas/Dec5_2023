from Organization import *
studentRecords = []
employeeRecords = []
while True:
    ch = int(input("Enter 1 STUDENT 2 EMPLOYEE 3 EXIT"))
    if ch==1:
        srec=createStudentEntry()
        studentRecords.append(srec)
        display(srec)
    elif ch==2:
        erec = createEmployeeEntry()
        employeeRecords.append(erec)
        displayEmployee(erec)
    elif ch==3:
        break
    else:
        print("Invalid choice")