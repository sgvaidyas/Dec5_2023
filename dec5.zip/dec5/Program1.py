def fun(*myargs):
    print(myargs)

fun("apple","mango")
fun(33,66,77,88)
fun("hhhh",999,"lll")