def add(a,b):
    print("SUM = ",a+b)
def mul(a,b):
    print("PROD = ",a*b)