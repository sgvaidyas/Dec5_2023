def createStudentEntry():
    id = input("Enter the id = ")
    name = input("Enter the name = ")
    fees = input(" Enter the fees = ")
    return [id,name,fees]

def display(sturec):
    print("------------------------")
    print("ID            = ",sturec[0])
    print("NAME          = ", sturec[1])
    print("FEES          = ", sturec[2])
    print("------------------------")

