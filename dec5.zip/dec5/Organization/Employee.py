def createEmployeeEntry():
    id = input("Enter the id = ")
    name = input("Enter the name = ")
    sal = input(" Enter the sal = ")
    exp = input("Enter the experience in years = ")
    return [id,name,sal,exp]


def displayEmployee(emprec):
    print("------------------------")
    print("ID            = ", emprec[0])
    print("NAME          = ", emprec[1])
    print("SAL           = ", emprec[2])
    print("EXP           = ", emprec[3])
    print("------------------------")

