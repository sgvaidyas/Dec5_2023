#import sys
#sys.path.insert(0,'C:/Users/Administrator/PycharmProjects/Dec5/myDir')
from myDir.myFunctions import  *

add(55,66)
mul(55,2)