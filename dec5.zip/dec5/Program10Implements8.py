from Program8 import addRecord,display
from Program11 import  mymessage
import myDir
rec = []
addRecord(rec)
addRecord(rec)
addRecord(rec)
display(rec)
# mymessage()
# myDir.add(22,44)

