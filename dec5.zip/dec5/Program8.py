def addRecord(rec):
    name = input("Enter the name = ")
    rec.append(name)

def display(rec):
    print("the names are ")
    for x in rec:
        print(x)

def search(key,rec):
    pass

