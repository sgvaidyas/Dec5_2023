def square(num):
    return num*num

def expon(base,exp):
    return base**exp

def rem(num,den):
    return num%den