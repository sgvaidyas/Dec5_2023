l = [11,22,33,44]

for x in l:
    print(x)





'''print(len(l))
# i = 0 i<4 i = i+1
for i in range(len(l)):
    print(l[i])  #l[3]'''


'''print(l[0])
print(l[1])
print(l[2])
print(l[3])'''
