'''for i in range(6):
    print(i)
print("-----------------------")

for i in range(2,6):
    print(i)
print("-----------------------")

for i in range(10,100,10):
    print(i)
print("-----------------------")
'''
'''
# i = 100 ; i>75 ; i=i-1
for i in range(100,75,-1):
    print(i)
print("----------------------")
for i in range(100, 10, -10):
    print(i)
'''
for i in range(10,20):
    if i%2==0:
        continue
    print(i)
print("---------------------")
for i in range(20):
    if i ==15:
        break
    print(i)










