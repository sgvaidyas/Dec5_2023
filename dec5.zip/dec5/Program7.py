'''a = []
print(a)
a = [11,22,33,44,55]
print(a)
a.append(999)
print(a)
a.append([88,99])
print(a)
a.extend([9999,8888,444,55])
print(a)'''
'''
a = [11,22,33,44,55]
b = [1,2,3,4]
c = a+b #concatenation
print(c)
d = a*2
print(d) #replication

'''
#membership
a = [11,22,33,44,55]
print(77 in a)
print(55 in a)
print(77 not in a)
print(55 not in a)
