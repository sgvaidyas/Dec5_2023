bill = 0
price = 0
qty = 0
while True:
    print("1 IDLI (20) 2 DOSA (35) 3 TEA (10) 4 EXIT")
    ch = int(input("Enter choice = "))
    if ch>=1 and ch<=3:
        qty=int(input("Enter the quantity ="))
    if ch==1:
        price = 20*qty
        bill = bill + price
        print("IDLI for ",qty," plates = ",price)
    elif ch==2:
        price = 35 * qty
        bill = bill + price
        print("DOSA for ", qty, " plates = ", price)
    elif ch == 3:
        price = 10 * qty
        bill = bill + price
        print("TEA for ", qty, " plates = ", price)
    elif ch == 4:
        print("==========================")
        print("BILL     = ",bill)
        break
    else:
        print("invalid")

