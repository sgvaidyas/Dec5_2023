from Calculator import  *

val = square(3)
print(val)
print(expon(3,4))

