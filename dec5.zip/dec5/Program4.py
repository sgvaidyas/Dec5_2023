#Loop running continuously till the condition is true
#1 to 100

'''i=1
while i<=100:
    print(i)
    i=i+1'''

'''
i=10
while i>=1:
    print(i)
    i=i-1'''
'''
takeinput = True
while takeinput==True:
    val = input("enter data : if you want to quit press 'quit' = ")
    if val == 'quit':
        #takeinput = False
        break
    else:
        print(val)
        
print("-------------------------")
'''
'''
i=10
while i<=20:
    if i==15 or i==17:
        i=i+1
        continue #skips every line below this for the current iteration 
    print(i)
    i=i+1

'''

#Skip all the elements if it is a multiple of 4
#11 to 45
i = 11
while i<=45:
    if i%4==0:
        i = i+1
        continue
    print(i)
    i=i+1







