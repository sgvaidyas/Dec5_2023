def mymessage():
    print("Welcome")