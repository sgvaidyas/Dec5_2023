#keywords args
def fun(**kargs):
    print(kargs)

fun(name="Shilpa",id=11,sal=900)
fun(roll=111,course="Python")